# Curso PySide6 Em Portugues
Curso gratuito de PySide6 em Português.

Projeto feito usando PySide6, VS Code, Qt Designer, Python 3.9.1 e Inkscape.

**Link YouTube: https://youtu.be/_qOnJ7-tJcM**
> **Layout do projeto**
![Preview_01](https://user-images.githubusercontent.com/60605512/127012774-4e0c8c33-de73-4582-bd01-cc32bbd21b7d.png)

