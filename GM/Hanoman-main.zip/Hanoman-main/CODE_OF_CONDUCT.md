## Hanoman  Code of Conduct
This repository is Open Source. so contribution is verry welcome

## How to contribute
The Code of Conduct is in a separate file so that it can be pulled
To contribute, fork this repo, and submit a PR. We'll review, discuss, and merge changes as needed. Thank you!

## Translations available
The Code of Conduct is currently available in:
- Bahasa Indonesia 

## Wishlist/To Do List:
We welcome contributions from community members interested in helping us maintain, and expand the coverage of this CoC
