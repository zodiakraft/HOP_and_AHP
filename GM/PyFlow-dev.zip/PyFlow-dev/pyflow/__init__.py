# -*- coding: utf-8 -*-
# Pyflow an open-source tool for modular visual programing in python
# Copyright (C) 2021-2022 Bycelium <https://www.gnu.org/licenses/>

""" Pyflow: An open-source tool for modular visual programing in python """

__appname__ = "Pyflow"
__author__ = "Mathïs Fédérico"
__version__ = "1.0.0"
