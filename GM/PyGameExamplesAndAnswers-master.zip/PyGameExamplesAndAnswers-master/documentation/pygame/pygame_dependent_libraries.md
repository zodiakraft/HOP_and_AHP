[![StackOverflow](https://stackexchange.com/users/flair/7322082.png)](https://stackoverflow.com/users/5577765/rabbid76?tab=profile) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [![reply.it](../../resource/logo/Repl_it_logo_80.png) reply.it](https://repl.it/repls/folder/PyGame%20Examples)

---

# Libraries based on PyGame

# PyGame Zero PgZrun

[PyGame Zero](https://pygame-zero.readthedocs.io/en/stable/)

Related Stack Overflow questions:

- [How to I make the actor jump without stopping the entire code?](https://stackoverflow.com/questions/58327639/how-to-i-make-the-actor-jump-without-stopping-the-entire-code/58327740#58327740)
- [How to make a Pygame Zero window full screen?](https://stackoverflow.com/questions/57522353/how-to-make-a-pygame-zero-window-full-screen/57522705#57522705)
- [Repeated key detection in PyGame Zero](https://stackoverflow.com/questions/57581656/repeated-key-detection-in-pygame-zero/57581845#57581845)
- [pygame - moving graphic (Actor)](https://stackoverflow.com/questions/59093294/pygame-moving-graphic-actor/59093538#59093538)
- [pygame - How to finish game?](https://stackoverflow.com/questions/59107919/pygame-how-to-finish-game/59108123#59108123)

## PyGame menu

[PyGame menu](https://www.pygame.org/project/3165)
