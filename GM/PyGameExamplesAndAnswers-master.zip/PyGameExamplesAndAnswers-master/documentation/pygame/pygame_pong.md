
[![StackOverflow](https://stackexchange.com/users/flair/7322082.png)](https://stackoverflow.com/users/5577765/rabbid76?tab=profile) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [![reply.it](../../resource/logo/Repl_it_logo_80.png) reply.it](https://repl.it/repls/folder/PyGame%20Examples)

---

# Pong

Related Stack Overflow questions:

- **[Sometimes the ball doesn't bounce off the paddle in pong game](https://stackoverflow.com/questions/62864205/sometimes-the-ball-doesnt-bounce-off-the-paddle-in-pong-game)**  
  ![Sometimes the ball doesn't bounce off the paddle in pong game](https://i.imgur.com/tF3EwGX.gif)

- [Implementing a collision detect feature between a Rect object and a ball in pygame](https://stackoverflow.com/questions/58716774/implementing-a-collision-detect-feature-between-a-rect-object-and-a-ball-in-pyga/58736372#58736372)  
  ![Implementing a collision detect feature between a Rect object and a ball in pygame](https://i.stack.imgur.com/mCtnM.gif)

- [Pong with Background Image](https://stackoverflow.com/questions/58751697/pong-with-background-image)  
- [Need to Get Black Hole Working, Has to Collide with Ball](https://stackoverflow.com/questions/58775396/need-to-get-black-hole-working-has-to-collide-with-ball/58777680#58777680)

- [Pong game in python. Score and out-of-screen check](https://stackoverflow.com/questions/62221432/pong-game-in-python-score-and-out-of-screen-check/62221774#62221774)  
  ![Pong game in python. Score and out-of-screen check](https://i.stack.imgur.com/AdKUV.gif)

- [Changing FPS on pygame in order to achieve smoothness of sprite's movement](https://stackoverflow.com/questions/59037251/changing-fps-on-pygame-in-order-to-achieve-smoothness-of-sprites-movement/65371237?noredirect=1)  
  ![Changing FPS on pygame in order to achieve smoothness of sprite's movement](https://i.stack.imgur.com/XTivx.gif)

- [How do I define collisions for x and y separately?](https://stackoverflow.com/questions/65531165/how-do-i-define-collisions-for-x-and-y-separately/65531270#65531270)
