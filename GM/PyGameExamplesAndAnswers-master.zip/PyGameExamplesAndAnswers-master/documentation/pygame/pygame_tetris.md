
[![StackOverflow](https://stackexchange.com/users/flair/7322082.png)](https://stackoverflow.com/users/5577765/rabbid76?tab=profile) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [![reply.it](../../resource/logo/Repl_it_logo_80.png) reply.it](https://repl.it/repls/folder/PyGame%20Examples)

---

# Tetris

Related Stack Overflow questions:

- [Tetris generating coloured shapes from blocks](https://stackoverflow.com/questions/66765536/tetris-generating-coloured-shapes-from-blocks/66767879#66767879)  
  ![Tetris generating coloured shapes from blocks](https://i.stack.imgur.com/F58Je.png)

  :scroll: **[Minimal example - Tetris shapes](../../examples/minimal_examples/pygame_minimal_tetris_shapes.py)**

- [Trying to delete two objects when placed next to eachother in pygame](https://stackoverflow.com/questions/56101697/trying-to-delete-two-objects-when-placed-next-to-eachother-in-pygame/56102178#56102178)  
  ![Trying to delete two objects when placed next to eachother in pygame](https://i.stack.imgur.com/lSdIg.gif)
