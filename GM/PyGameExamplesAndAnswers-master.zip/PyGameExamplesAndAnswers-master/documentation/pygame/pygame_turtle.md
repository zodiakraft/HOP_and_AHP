[![StackOverflow](https://stackexchange.com/users/flair/7322082.png)](https://stackoverflow.com/users/5577765/rabbid76?tab=profile) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [![reply.it](../../resource/logo/Repl_it_logo_80.png) reply.it](https://repl.it/repls/folder/PyGame%20Examples)

---

# Turtle

Related Stack Overflow questions:

- [Is there a .stamp() method in pygame like in turtle?](https://stackoverflow.com/questions/66485793/is-there-a-stamp-method-in-pygame-like-in-turtle/66504640#66504640)  
  ![Is there a .stamp() method in pygame like in turtle?](https://i.stack.imgur.com/5lSCG.gif)

  :scroll: **[Minimal example - Turtle stamp](../../examples/minimal_examples/pygame_minimal_turtle_stamp.py)**
