[![StackOverflow](https://stackexchange.com/users/flair/7322082.png)](https://stackoverflow.com/users/5577765/rabbid76?tab=profile) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; [![reply.it](../../../resource/logo/Repl_it_logo_80.png) reply.it](https://repl.it/repls/folder/PyGame%20Examples)

---

# Rubik's Cube

## Stack Overflow questions

[How to group, then rotate and translate grouped objects in python opengl](https://stackoverflow.com/questions/50303616/how-to-group-then-rotate-and-translate-grouped-objects-in-python-opengl)  

See then [answer](so_pygame_opengl_rubiks_1.md)

[![](https://i.stack.imgur.com/ZriyZ.gif)](so_pygame_opengl_rubiks_1.md)

[OpenGL Rubik's Cube colors not displaying correctly when turning](https://stackoverflow.com/questions/56729403/opengl-rubiks-cube-colors-not-displaying-correctly-when-turning)