# Resource

Photos from [Unsplash Photos for everyone](https://unsplash.com/)

Clip arts from [FreeSVG.org](https://freesvg.org/)

Animations from [Animated Gifs, Animated Image](https://www.animatedimages.org/)

Free assets for everyone [freebies.html](https://www.gameart2d.com/freebies.html)

OpenGameArt.org [opengameart.org/](https://opengameart.org/)

Free world maps [free-world-maps.com](http://www.free-world-maps.com/)
