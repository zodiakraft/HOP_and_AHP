# PyQt5-splashScreen
PyQt5 splash screen using Python programmer
