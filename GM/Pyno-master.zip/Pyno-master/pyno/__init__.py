"""Pyno: Python-based data-flow visual programming."""

from .runner import run

__version__ = '1.2.0'
