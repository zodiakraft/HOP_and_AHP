"""Provide a way to run pyno using the Python interpreter directly."""

from .runner import run

run()
