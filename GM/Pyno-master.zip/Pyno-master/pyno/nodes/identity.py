def identity(x=None):
    return x

call = identity
