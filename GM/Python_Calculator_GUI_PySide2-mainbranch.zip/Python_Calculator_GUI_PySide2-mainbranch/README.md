# Python Calculator GUI PySide2
This is my first application created with Python and using PySide2

# REQUERIMENTS:
PySide2: pip install PySide2
