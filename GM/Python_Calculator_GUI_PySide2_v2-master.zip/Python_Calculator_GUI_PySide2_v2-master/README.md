# Python Calculator GUI PySide2
This is my first application created with Python and using PySide2

# Warning ⚠️
> This was my first Python project when I was studying, it has a lot of deprecated code, but it won't be supported.  I just made a few small changes so that I have separated the interface file (main_ui.py) separate from the logic file.

# REQUERIMENTS:
PySide2: pip install PySide2
