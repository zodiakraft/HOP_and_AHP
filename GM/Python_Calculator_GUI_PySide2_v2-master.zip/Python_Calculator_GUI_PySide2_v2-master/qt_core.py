from PySide2 import QtCore, QtGui, QtWidgets
from PySide2.QtCore import (QCoreApplication, QSize, Qt)
from PySide2.QtGui import QFont
from PySide2.QtWidgets import *