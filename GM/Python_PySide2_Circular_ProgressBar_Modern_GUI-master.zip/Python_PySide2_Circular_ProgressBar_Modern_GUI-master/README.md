# Python PySide2 - Circular ProgressBar - Modern GUI
Project created in Python using the PySide2 module.
Circular Progress Bar created with native QWidgets features and a Flat/Modern visual interface.
![image-1](https://user-images.githubusercontent.com/60605512/90970977-bbef0600-e4e1-11ea-9df8-e3ed970934e0.png)
![image-2](https://user-images.githubusercontent.com/60605512/90970980-be516000-e4e1-11ea-91fd-6706d684a295.png)

# Youtube Video:
https://youtu.be/zUnrLHbYmKA
