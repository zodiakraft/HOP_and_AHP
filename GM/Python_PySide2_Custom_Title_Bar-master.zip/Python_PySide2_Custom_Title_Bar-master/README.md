# Python PySide2 Custom Title Bar [Modern GUI]
![App_1](https://user-images.githubusercontent.com/60605512/86516153-a53b0580-bdf4-11ea-9966-31ac1c9effcf.PNG)
A simple project created with PySide2 and Qt Designer showing how it works to create a customizable application

# Youtube
https://youtu.be/wQfKamzV1uQ
