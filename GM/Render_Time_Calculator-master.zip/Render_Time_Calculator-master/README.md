# Render Time Calculator - Open Code
Render Time Calculator prview:
![RTC_3](https://user-images.githubusercontent.com/60605512/83827524-ebe1f680-a6b4-11ea-83e1-179e57443839.PNG)

# Requeriments
Python 3.7 >
PySide2
PyTimeParse
