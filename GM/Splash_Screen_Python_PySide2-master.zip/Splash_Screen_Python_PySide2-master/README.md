# Splash Screen Python PySide2/PyQt5 - MODERN GUI
![Capa](https://user-images.githubusercontent.com/60605512/89593731-479c3d80-d826-11ea-8788-905a9b09f4ae.png)
