# modern-login

### A simple login form built with PyQt 5

[![Python: 3.x](https://img.shields.io/badge/python-3.x-blue?logo=python&logoColor=FFE873)](https://www.python.org/downloads)
[![PyQt: 5.14.0](https://img.shields.io/badge/pyqt-5.14.0-darkgreen)](https://pypi.org/project/PyQt5)

___

[![animation][1]][1]

[1]: https://raw.githubusercontent.com/sinusphi/modern-login/main/img/animation.gif
