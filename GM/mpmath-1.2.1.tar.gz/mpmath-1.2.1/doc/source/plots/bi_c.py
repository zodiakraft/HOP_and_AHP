# Airy function Bi(z) in the complex plane
cplot(airybi, [-8,8], [-8,8], points=50000)
