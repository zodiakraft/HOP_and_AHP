.. _guides:

==============
 SymPy Guides
==============

.. toctree::
   :maxdepth: 2

   assumptions.rst
   booleans.rst
