.. _combinatorics-testutil:

Test Utilities
==============

.. module:: sympy.combinatorics.testutil

.. autofunction:: _cmp_perm_lists

.. autofunction:: _naive_list_centralizer

.. autofunction:: _verify_bsgs

.. autofunction:: _verify_centralizer

.. autofunction:: _verify_normal_closure
