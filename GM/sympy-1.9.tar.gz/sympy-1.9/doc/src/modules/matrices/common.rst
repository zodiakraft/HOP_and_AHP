Common Matrices
===============

.. module:: sympy.matrices.common

MatrixCommon Class Reference
----------------------------
.. autoclass:: MatrixCommon
   :members:
   :special-members:
   :inherited-members:
