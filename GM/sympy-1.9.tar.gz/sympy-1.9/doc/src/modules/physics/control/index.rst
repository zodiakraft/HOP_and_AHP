==============
Control Module
==============

.. module:: sympy.physics.control

.. topic:: Abstract

    Contains docstrings of Physics-Control module


.. toctree::
    :maxdepth: 3

    control.rst
    lti.rst
    control_plots.rst
