=====================
Printing (Docstrings)
=====================


mechanics_printing
==================

This function is the same as :obj:`sympy.physics.vector.printing.init_vprinting`.


mprint
======

This function is the same as :obj:`sympy.physics.vector.printing.vprint`.


mpprint
=======

This function is the same as :obj:`sympy.physics.vector.printing.vpprint`.


mlatex
======

This function is the same as :obj:`sympy.physics.vector.printing.vlatex`.
