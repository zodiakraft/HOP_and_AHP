==================================
Quantum Harmonic Oscillator in 1-D
==================================

.. automodule:: sympy.physics.qho_1d
   :members:
