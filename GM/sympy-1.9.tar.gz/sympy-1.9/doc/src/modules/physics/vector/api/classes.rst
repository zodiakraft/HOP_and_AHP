=================
Essential Classes
=================

CoordinateSym
=============

.. autoclass:: sympy.physics.vector.frame.CoordinateSym
   :members:


ReferenceFrame
==============

.. autoclass:: sympy.physics.vector.frame.ReferenceFrame
   :members:


Vector
======

.. autoclass:: sympy.physics.vector.vector.Vector
   :members:


Dyadic
======

.. autoclass:: sympy.physics.vector.dyadic.Dyadic
   :members:
