========
Simplify
========

.. toctree::
   :maxdepth: 2

   simplify.rst
   hyperexpand.rst
   fu.rst
