.. _utilities-docs:

=========
Utilities
=========

.. automodule:: sympy.utilities

Contents:

.. toctree::
   :maxdepth: 2

   autowrap.rst
   codegen.rst
   decorator.rst
   enumerative.rst
   iterables.rst
   lambdify.rst
   memoization.rst
   misc.rst
   pkgdata.rst
   source.rst
   timeutils.rst
