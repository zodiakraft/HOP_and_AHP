.. _special_topics:

=====================
 SymPy Special Topics
=====================

.. toctree::
   :maxdepth: 2

   intro.rst
   finite_diff_derivatives.rst
   classification.rst
